const router = require('express').Router();

const students = [
    {
        name: "GIFTY AWO WOSORNU",
        DOB: "12/04/1982",
        program: "BSC MIS",
        level: "200",
        image:"/images/img1.jpeg"
    },
    {
        name: "AWO WOSORNU",
        DOB: "12/20/1990",
        program: " IT LAW",
        level: "200",
        image:"/images/img2.jpeg"
    },
    {
        name: "GIFTY AWO",
        DOB: "29/20/1995",
        program: "BSC BANKING & FINANCE",
        level: "200",
        image:"/images/img3.jpeg"
    },
    {
        name: "GIFTY WOSORNU ",
        DOB: "09/10/1987",
        program: "BSC PUBLIC ADMINISTRATION",
        level: "200",
        image:"/images/img4.jpeg"
    },
    {
        name: "GIFTY A WOSORNU",
        DOB: "12/06/1998",
        program: "BSC COMPUTER SCIENCE",
        level: "200",
        image:"/images/img5.jpeg"
    }
]


router.get('/', (req, res)=>{
    res.render('home', {
        title:'Home',
        students
    })
});

router.get('/student/:id', (req, res)=>{
    const id = req.params.id;
    const student = students[id];
    res.render('student', {
        title: students[id].name,
        student
    })
});

module.exports = router;